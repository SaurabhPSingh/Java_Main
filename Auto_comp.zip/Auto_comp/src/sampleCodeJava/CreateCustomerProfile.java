package sampleCodeJava;

import net.authorize.Environment;
import net.authorize.api.contract.v1.*;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.math.BigDecimal;

import au.com.bytecode.opencsv.CSVReader;
import au.com.bytecode.opencsv.CSVWriter;
import net.authorize.api.controller.CreateCustomerProfileController;
import net.authorize.api.controller.base.ApiOperationBase;

public class CreateCustomerProfile {

	public static ANetApiResponse run(String apiLoginId, String transactionKey, String eMail) throws IOException 
	{
		ApiOperationBase.setEnvironment(Environment.SANDBOX);

        MerchantAuthenticationType merchantAuthenticationType  = new MerchantAuthenticationType() ;
        merchantAuthenticationType.setName(apiLoginId);
        merchantAuthenticationType.setTransactionKey(transactionKey);
        ApiOperationBase.setMerchantAuthentication(merchantAuthenticationType);
        CreditCardType creditCard = new CreditCardType();
		creditCard.setCardNumber("4111111111111111");
	    creditCard.setExpirationDate("0718");
		PaymentType paymentType = new PaymentType();
		paymentType.setCreditCard(creditCard);

		CustomerPaymentProfileType customerPaymentProfileType = new CustomerPaymentProfileType();
		customerPaymentProfileType.setCustomerType(CustomerTypeEnum.INDIVIDUAL);
		customerPaymentProfileType.setPayment(paymentType);
		
		
		File inputFile=new File(System.getProperty("user.dir")+"\\src\\CSV_Files\\Customers_Create_Customer.csv");
		CSVReader csvReader = new CSVReader(new FileReader(inputFile));
		String[] columns = null;
		csvReader.readNext();
		CreateCustomerProfileResponse response=null;
		while((columns = csvReader.readNext()) != null)
		{	
        CustomerProfileType customerProfileType = new CustomerProfileType();
        customerProfileType.setMerchantCustomerId("M_" + columns[1]);
        customerProfileType.setDescription("Profile description for " + columns[2]);
        customerProfileType.setEmail(columns[3]);
        customerProfileType.getPaymentProfiles().add(customerPaymentProfileType);

        CreateCustomerProfileRequest apiRequest = new CreateCustomerProfileRequest();
        apiRequest.setProfile(customerProfileType);
        apiRequest.setValidationMode(ValidationModeEnum.TEST_MODE);
        CreateCustomerProfileController controller = new CreateCustomerProfileController(apiRequest);
        controller.execute();
        response = controller.getApiResponse();
    	File opFile=new File(System.getProperty("user.dir")+"\\src\\CSV_Files\\Output.csv");
		CSVWriter writer = new CSVWriter(new FileWriter(opFile,true));
        if (response!=null) 
        {

             if (response.getMessages().getResultCode() == MessageTypeEnum.OK) 
             {

                System.out.println(response.getCustomerProfileId());
                if(!response.getCustomerPaymentProfileIdList().getNumericString().isEmpty())
                	System.out.println(response.getCustomerPaymentProfileIdList().getNumericString().get(0));
                if(!response.getCustomerShippingAddressIdList().getNumericString().isEmpty())
                	System.out.println(response.getCustomerShippingAddressIdList().getNumericString().get(0));
                if(!response.getValidationDirectResponseList().getString().isEmpty())
                	System.out.println(response.getValidationDirectResponseList().getString().get(0));
        		
        		String [] outputArr = {"CreateCustomerProfile",columns[0],"Passed","Expected"};
        		writer.writeNext(outputArr);
        		writer.close();
        		System.out.println(outputArr);
            }
            else
            {
                System.out.println("Failed to create customer profile:  " + response.getMessages().getResultCode());        	
        		String [] outputArr = {"CreateCustomerProfile",columns[0],"Failed","TC Failed since no reponse"};
        		writer.writeNext(outputArr);
        		writer.close();
            }
        }
        else
        {
        	
    		String [] outputArr = {"CreateCustomerProfile",columns[0],"Failed","TC Failed since no reponse"};
    		writer.writeNext(outputArr);
    		writer.close();
        }
		
		}
		return response;
    }
}