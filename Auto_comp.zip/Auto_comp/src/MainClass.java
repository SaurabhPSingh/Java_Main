import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import au.com.bytecode.opencsv.CSVReader;
import au.com.bytecode.opencsv.CSVWriter;
import sampleCodeJava.GetTransactionList;
import sampleCodeJava.CreateCustomerProfile;

public class MainClass {

	public static void main(String[] args) throws IOException, NoSuchMethodException, SecurityException, InstantiationException, IllegalAccessException, ClassNotFoundException, IllegalArgumentException, InvocationTargetException 
	{
		File opFile=new File(System.getProperty("user.dir")+"\\src\\CSV_Files\\Output.csv");
		CSVWriter writer = new CSVWriter(new FileWriter(opFile));
		String [] columnNames = "API_Name#TestCaseID#Result#Remarks".split("#");

		writer.writeNext(columnNames);

		writer.close();
		//the code above is for writing the column names in the output file
		
		
		File driverFile=new File(System.getProperty("user.dir")+"\\src\\CSV_Files\\driver.csv");
		CSVReader csvReader = new CSVReader(new FileReader(driverFile));
		String[] columns = null;
		csvReader.readNext();
		while((columns = csvReader.readNext()) != null)
		{
			if(columns[2].equals("1"))
			{
				Object obj = Class.forName("sampleCodeJava."+columns[1]).newInstance();
				Method runM=obj.getClass().getMethod("run",String.class,String.class,String.class);
				runM.invoke(obj,"34vkyg66qHR4","7pfZ3Rac888ED899 ","ss");
			}
		}
		
		csvReader.close();
	}
}
